import { Link, useNavigate, Outlet } from "react-router-dom";

export default function List() {
	const navigate = useNavigate();

	console.log(navigate);
	return (
		<div>
			<h1>List</h1>
			<Link to={"123"}>HOLA ITEM 123</Link>
			<br />
			<button>
				<Link to="/">Back</Link>
			</button>

			<Outlet />
		</div>
	);
}
