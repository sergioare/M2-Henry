import { Link, useLocation } from "react-router-dom";

export default function Home() {
	const location = useLocation();

	console.log(location);

	return (
		<div>
			<h1>Home</h1>
			<button>
				<Link to="/">Back</Link>
			</button>
		</div>
	);
}
