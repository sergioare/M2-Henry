import { useParams } from "react-router-dom";

export default function ListItem() {
	const { itemId, status } = useParams(); // { itemId, status }

	return (
		<div>
			<h2>Soy el List Item #{itemId} y mi status es {status}</h2>
		</div>
	);
}
