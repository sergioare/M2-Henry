import { NavLink } from "react-router-dom";

/*
styles.css
	.active {
		font-size: 50px;
		text-decoration: underline;
	}


*/

export default function Welcome() {
	return (
		<div>
			<h1>Welcome</h1>

			<div>
				<NavLink
					to="/home"
					className={({ isActive }) => (isActive ? "active" : undefined)}
				>
					Home
				</NavLink>
				<br />
				<NavLink
					to="/about"
					style={({ isActive }) =>
						isActive ? { backgroundColor: "blue" } : { backgroundColor: "yellow" }
					}
				>
					About
				</NavLink>
				<br />
				<NavLink to="list">List</NavLink>
				<br />
				<NavLink to="list/123">List Item</NavLink>
			</div>
		</div>
	);
}
