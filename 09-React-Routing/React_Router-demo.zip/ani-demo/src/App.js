import { BrowserRouter, Routes, Route } from "react-router-dom";
import About from "./components/About.jsx";
import Home from "./components/Home.jsx";
import Welcome from "./components/Welcome.jsx";
import List from "./components/List.jsx";
import ListItem from "./components/ListItem.jsx";

function App() {
	return (
		<BrowserRouter>
			<Routes>
				<Route path="/" element={<Welcome />}></Route>
				<Route path="home" element={<Home />} />
				<Route path="about" element={<About />} />
				<Route path="list" element={<List />}>
					<Route path=":itemId/:status" element={<ListItem />} />
				</Route>
			</Routes>
		</BrowserRouter>
	);
}

// function DemoApp() {
// 	return (
// 		<BrowserRouter>
// 			<Routes>
// 				<Route path="marketplace" element={<Marketplace />} />
// 				<Route path=":username" element={<Profile />} />
// 				<Route path="sales" element={<Sales />}>
// 					<Route path="invoices" element={<Invoices />}>
// 						<Route path=":invoiceID" element={<InvoiceDetails />} />
// 					</Route>
// 				</Route>
// 			</Routes>
// 		</BrowserRouter>
// 	);
// }

export default App;
