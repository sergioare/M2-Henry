import React from "react";
import Zoo from "./components/Zoo/Zoo.jsx";

export default function App() {
  return (
    <div>
      <Zoo />
    </div>
  );
}
